/** @format */

export type IDevice = {
  id: string;
  location_id: string;
  mac: string;
};
