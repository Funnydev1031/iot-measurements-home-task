/** @format */
export type ILocation = {
  id: string;
  name: string;
};
